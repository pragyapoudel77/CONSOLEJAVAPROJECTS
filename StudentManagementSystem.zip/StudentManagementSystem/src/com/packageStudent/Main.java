package com.packageStudent;

import java.sql.*;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int choice = 0;
		
		do {
			System.out.println("\n ====== Student Management System");
			System.out.println("1. Add Student");
			System.out.println("2.List Students");
			System.out.println("3.Update Student");
			System.out.println("4.Delete Student");
			System.out.println("5.Exit");
			
			System.out.print("Enter choice from 1 to 5");
			choice = sc.nextInt();
			sc.nextLine();
			
			switch(choice) {
			
			
			case 1:
				addStudent(sc);
				break;
			
			case 2:
				viewStudents();
				break;
			case 3:
				updateStudent(sc);
				break;
			case 4:
				deleteStudent(sc);
				break;
			case 5:
				System.out.println("Exiting.....");
				break;
			default:
				System.out.println("Invalid Choice");
				
			}
		}while(choice!= 5);
		
		sc.close();
	}
	
	private static void addStudent(Scanner sc) {
		
		System.out.print("Enter Name:");
		String name = sc.nextLine();
		
		System.out.print("Enter Age:");
		int age = sc.nextInt();
		sc.nextLine();
		
		System.out.print("Enter Grade:");
		String grade = sc.nextLine();
		
		System.out.print("Enter Email");
		String email = sc.nextLine();
		
		String sql = "INSERT INTO student(name, age,grade, email) VALUES(?,?,?,?)";
		try(Connection conn = DBConnection.getConnection();
				PreparedStatement stmt = conn.prepareStatement(sql)) {
				stmt.setString(1,name);
				stmt.setInt(2,age);
				stmt.setString(3,grade);
				stmt.setString(4, email);
				
				int rows = stmt.executeUpdate();
				System.out.println(rows + "student added");
		}catch (SQLException e) {
			System.out.println("Error:"+e.getMessage());
				
		}
	}
	
	private static void viewStudents() {
		String sql = "SELECT * FROM student";
		try (Connection conn = DBConnection.getConnection();
			 Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(sql)){
			
			System.out.println("ID\tName\tAge\tGrade\tEmail");
			System.out.println("----------------------");
			while(rs.next()) {
				System.out.println(rs.getInt("id")+"\t" +
							rs.getString("name") + "\t" + 
							rs.getInt("age")+ "\t" +
							rs.getString("grade") + "\t" +
							rs.getString("email"));
			}
			
		} catch (SQLException e) {
			System.out.println("Error:"+ e.getMessage());
			
		}
	}
	private static void updateStudent(Scanner sc) {
		System.out.print("Enter Student ID to update:");
		int id = sc.nextInt();
		sc.nextLine();
		
		System.out.print("Enter new Name:");
		String name = sc.nextLine();
		
		System.out.print("Enter new Age:");
		int age = sc.nextInt();
		sc.nextLine();
		
		System.out.print("Enter new Grade");
		String grade = sc.nextLine();
		
		System.out.print("Enter new Email");
		String email = sc.nextLine();
		
		String sql = "UPDATE student SET name=?, age=?,grade=?, email=? WHERE id =?";
		try (Connection conn = DBConnection.getConnection();
				PreparedStatement stmt = conn.prepareStatement(sql)){
				stmt.setString(1, name);
				stmt.setInt(2, age);
				stmt.setString(3,  grade);
				stmt.setString(3, grade);
				stmt.setInt(5, id);
				
				int rows = stmt.executeUpdate();
				System.out.println(rows + " student updated.");
				
		}catch(SQLException e) {
			System.out.println("Error:" + e.getMessage());
			
			
		}
	}
	private static void deleteStudent(Scanner sc) {
		System.out.print("Enter Student ID to delete:");
		int id = sc.nextInt();
		
		String sql = "DELETE FROM student WHERE id=?";
		try (Connection conn = DBConnection.getConnection();
				PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setInt(1, id);
			int rows = stmt.executeUpdate();
			System.out.println(rows + "student deleted.");
			
		} catch(SQLException e) {
			System.out.println("Error:"+ e.getMessage());
		}
				
				
				
				
				
				
				
				
		
	}
}
