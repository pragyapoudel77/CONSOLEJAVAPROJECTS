package com.packageStudent;


import java.sql.*;

public class DBConnection {
	private static final String URL = "jdbc:mysql://localhost:3306/student_db";
	private static final String USERNAME = "root";
	private static final String PASSWORD = "Pwd/1234";
	
	public static Connection getConnection() {
		try {
			return DriverManager.getConnection(URL,USERNAME,PASSWORD);
		} catch(SQLException e) {
			System.out.println("DB Connection failed" + e.getMessage());
			return null;
		}
	}
	

}
