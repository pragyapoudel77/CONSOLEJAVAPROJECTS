package crud.com;

import java.sql.*;
import java.util.*;


public class Main {
	private static final String URL ="jdbc:mysql://localhost:3306/java_project";
	private static final String USER = "root";
	private static final String PASSWORD ="Pwd/1234";
	
	public static void main(String[] args) {
		
		try(
				Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
				Scanner sc = new Scanner(System.in)
			)
		
		{
			int choice;
			
			while(true) {
				System.out.println("\n========= MENU =========");
				
				System.out.println("1. Add item");
				System.out.println("2. List Items");
				System.out.println("3. Update Items");
				System.out.println("4. Delete Item");
				System.out.println("5. Search Items");
				System.out.println("6. Exit");
				
				System.out.println("Enter choice: ");
				choice = sc.nextInt();
				sc.nextLine();
				
				switch(choice) {
				case 1:
					System.out.print("Enter item name: ");
					String name = sc.nextLine();
					addItem(conn,name);
					break;
				
				case 2:
					listItems(conn);
					break;
					
				case 3:
					System.out.print("Enter item ID to update: ");
					
					int updateId = sc.nextInt();
					sc.nextLine();
					System.out.println("Enter new name:");
					String newName = sc.nextLine();
					updateItem(conn,updateId,newName);
					break;
				
				case 4:
					System.out.print("Enter item ID to delete");
					int deleteId = sc.nextInt();
					deleteItem(conn,deleteId);
					
				case 5:
					System.out.print("Enter name to search:");
					String searchName = sc.nextLine();
					searchItem(conn,searchName);
					break;
					
				case 6:
					System.out.println("Exiting program...");
					return;
					
				default:
					System.out.println("Invalid choice!Try again");
					
				}
				
					
				
				
			}
			
		}
		
		catch(SQLException e) {
			e.printStackTrace();
			
		}
				
				
	}
	
	
	
	
	
	
	
	
	
	//AddItem Function 
	
	private static void addItem(Connection conn, String name) throws SQLException
	{
		String sql = "INSERT INTO items(name) VALUES (?)";
		
		try(PreparedStatement stmt = conn.prepareStatement(sql))
		{
			stmt.setString(1, name);
			stmt.executeUpdate();
			System.out.println("Item added successfully");
		}
	}
	
	
	
	
	
	
	
	// ListItem Function
	
	private static void listItems(Connection conn) throws SQLException
	{
		String sql = "SELECT * FROM items";
		try(Statement stmt = conn.createStatement();
				ResultSet rs= stmt.executeQuery(sql)) {
				System.out.println("\n --- Items List ----");
				boolean found = false;
				while(rs.next()) {
					found = true;
					System.out.println(rs.getInt("id") + ". "+rs.getString("name"));
				}
				
				if(!found) {
					System.out.println("No items found");
				}
		
			
			
		}
	}
	
	//deleteItem
	
	private static void updateItem(Connection conn, int id,String newName) throws SQLException 
	{
		String sql = "UPDATE items SET name = ? WHERE id=?";
		
		try(PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setString(1,  newName);
			stmt.setInt(2,id);
			int rows = stmt.executeUpdate();
			if(rows > 0) {
				System.out.println("Item updated successfully");
				
			}
			else {
				System.out.println("Item not found");
			}
		}
	}
	
	//Function deleteItem
	private static void deleteItem(Connection conn, int id) throws SQLException 
	{
		String sql = "DELETE FROM items WHERE id =?";
		
		try (PreparedStatement stmt = conn.prepareStatement(sql)){
			stmt.setInt(1,  id);
			int rows = stmt.executeUpdate();
			if(rows > 0) {
				System.out.println("Item deleted successfully");
				
			}
			else {
				System.out.println("Item not found.");
			}
		}
	}
	
	//Search Items
	private static void searchItem(Connection conn, String name) throws SQLException {
		String sql = "SELECT * FROM items WHERE name LIKE ?";
		try (PreparedStatement stmt = conn.prepareStatement(sql)){
			stmt.setString(1,  "%" + name + "%");
			try (ResultSet rs = stmt.executeQuery()){
				System.out.println("\n------- Search Results-----");
				boolean found = false;
				while(rs.next()) {
					found = true;
					System.out.println(rs.getInt("id") + "." +rs.getString("name"));
					
					
				}
				if(!found) {
					System.out.println("No matching item found");
				}
			}
		}
	}
	
	
	//Ending curly braces
	

}
