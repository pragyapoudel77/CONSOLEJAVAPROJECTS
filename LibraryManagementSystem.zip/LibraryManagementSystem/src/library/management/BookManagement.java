package library.management;

import java.util.ArrayList;
import java.util.Scanner;

public class BookManagement {
	
	public static void main() {
		ArrayList<Book> books =  new ArrayList<>();
		
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			System.out.println("1. Add Book 2. List Book 3. Exit");
			
			int choice10 = sc.nextInt();
			sc.nextLine();
			
			if(choice10 == 1) 
			{
				System.out.println("Enter Book Id");
				int id = sc.nextInt();
				sc.nextLine();
				
				System.out.println("Enter Book Title");
				String title = sc.nextLine();
				
				System.out.println("Enter author name:");
				String author = sc.nextLine();
				
				books.add(new Book(id,title,author));
				System.out.println("Book Added");
				
				
				
			}
			
			else if (choice10 == 2) 
			{
				for(Book b: books) {
					System.out.println(b);
				}
			}
			
			else if(choice10 == 3)
			{
				System.out.println("Exiting");
				break;
			}
			
			else {
				System.out.println("Invalid choice! Try again");
			}
			
		}
		
		sc.close(); 
		
		
	}
	
	
	
}
