package library.management;


public class Book {
	int id;
	String title10;
	String author10;
	
	Book(int id, String title, String author){
		this.id = id;
		this.title10 = title;
		this.author10 = author;
	}
	
	public String toString() {
		return id + " - " + title10 + " - " + author10;
	}
	

}
