package com.practice;
import java.util.ArrayList;
import java.util.Scanner;

public class StudentManager {
	ArrayList<Student> students = new ArrayList<>();
	
	void addStudent(Student s) {
		students.add(s);
		System.out.println("Student Added");
	}
	
	void listStudents() {
		for (Student s : students) {
			System.out.println(s);
		}
	}
	public static void main(String[] args) {
		StudentManager sm = new StudentManager();
		Scanner sc = new Scanner(System.in);
		
		while(true) 
		{
			System.out.println("1.Add Student 2.List Students 3.exit");
			int choice = sc.nextInt();
			
			sc.nextLine();
			
			if(choice == 1) {
				System.out.println("ID: ");
				int id = sc.nextInt();
				sc.nextLine();
				System.out.println("Name:");
				String name = sc.nextLine();
				System.out.println("Age: ");
				int age = sc.nextInt();
				
				sm.addStudent(new Student(id,name,age));
		 }
			else if (choice ==2) {
				sm.listStudents();
			} else {
				break;
			}
		}
		
		sc.close();
	}

}
