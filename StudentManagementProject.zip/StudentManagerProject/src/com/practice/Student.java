package com.practice;

public class Student {
	
	int id;
	String name10;
	int age10;
	
	Student(int id, String name, int age){
		this.id = id;
		this.name10 = name;
		this.age10 = age;
		
	}
	
	public String toString() {
		return id + " - " +age10;
	}

}
