package employeecontact;

import java.sql.*;
import java.util.Scanner;

public class Employees {
	//Variable names to connect to database
	
	
	
	private static final String URL = "jdbc:mysql://localhost:3306/CompanyEmployeesInfo";
	private static final String USERNAME ="root";
	private static final String PASSWORD ="Pwd/1234";
	
	public static void main(String[] args) 
	{
		
		try 
			(Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			Scanner sc = new Scanner(System.in)) 
			{
				
			
		
		
		
		while(true) {
			
			System.out.println("\n =========MENU=========");
			System.out.println("1. Add Employee");
			System.out.println("2. List Employee");
			System.out.println("3. Update Employee");
			System.out.println("4. Delete Employee");
			System.out.println("5. Search Employees");
			System.out.println("6. Exit");
			System.out.println("Enter choice:");
			
			int choice = sc.nextInt();
			sc.nextLine();
			
			switch(choice) {
			
			case 1:
				
				addEmployee(conn,sc);
				break;
			
			case 2:
				listEmployees(conn);
				break;
				
			case 3:
				updateEmployee(conn,sc);
				break;
			case 4:
				deleteEmployee(conn,sc);
				break;
			case 5:
				searchEmployee(conn,sc);
				break;
			case 6:
				System.out.println("Exiting....");
				return;
			default:
				System.out.println("Invalid Choice");
			}
				
			}
			
			}catch (SQLException e) {
				e.printStackTrace();
			}
		
			
			
			
			
		
		
		
		
	}
	
	public static void addEmployee(Connection conn , Scanner sc) throws SQLException{
		
		System.out.print("Enter First Name");
		String first_name = sc.nextLine();
		System.out.print("Enter Last Name");
		String last_name = sc.nextLine();
		System.out.print("Enter Gender");
		String gender = sc.nextLine();
		System.out.print("Enter Date of Birth");
		String dob =sc.nextLine();
		System.out.print("Enter Phone Number");
		String phone =sc.nextLine();
		System.out.print("Enter Department");
		String department = sc.nextLine();
		System.out.print("Enter Position");
		String position =sc.nextLine();
		System.out.print("Enter Hire Date");
		String hire_date =sc.nextLine();
		System.out.print("Enter Salary");
		String salary = sc.nextLine();
		
		String sql = "INSERT INTO EmployeesContactInfo(first_name,last_name,gender,dob,phone,department,position,hire_date,salary) VALUES (?,?,?,?,?,?,?,?,?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)){
        	stmt.setString(1,first_name);
        	stmt.setString(2,last_name);
        	stmt.setString(3,gender);
        	stmt.setString(4,dob);
        	stmt.setString(5,phone);
        	stmt.setString(6,department);
        	stmt.setString(7,position);
        	stmt.setString(8,hire_date);
        	stmt.setString(9,salary);
        	
        	stmt.executeUpdate();
        	System.out.println("Employee's Contact Added");
        }
	}
	
	public static void listEmployees(Connection conn)  throws SQLException {
		String sql = "SELECT * FROM EmployeesContactInfo";
		
		try(Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(sql)){
			System.out.println("\n ------- Employee List-----");
			boolean found = false;
			while(rs.next()) {
				found = true;
				System.out.printf("%d | %s | %s | %s |%s |%s |%s |%s |%s |%s\n",
						rs.getInt("id"),
						rs.getString("first_name"),
						rs.getString("last_name"),
						rs.getString("gender"),
						rs.getString("dob"),
						rs.getString("phone"),
						rs.getString("department"),
						rs.getString("position"),
						rs.getString("hire_date"),
						rs.getString("salary"));
						
			}   
			if(!found) {
				System.out.println("No Employees found.");
			}
		}
				
	}
	
	public static void updateEmployee(Connection conn, Scanner sc)  throws SQLException {
		
		System.out.print("Enter Employee ID to update");
		int id = sc.nextInt();
		sc.nextLine();
		
		System.out.print("Enter First Name");
		String first_name = sc.nextLine();
		sc.nextLine();
		
		System.out.print("Enter Last Name");
		String last_name = sc.nextLine();
		sc.nextLine();
		
		System.out.print("Enter Gender");
		String gender = sc.nextLine();
		sc.nextLine();
		
		System.out.print("Enter Date of Birth");
		String dob = sc.nextLine();
		sc.nextLine();
		
		System.out.print("Enter Phone Number");
		String phone = sc.nextLine();
		sc.nextLine();
		
		System.out.print("Enter Department");
		String department = sc.nextLine();
		sc.nextLine();
		
		System.out.print("Enter Position of Employee's Post");
		String position = sc.nextLine();
		sc.nextLine();
		
		System.out.print("Enter Hire Date of Employee");
		String hire_date = sc.nextLine();
		sc.nextLine();
		
		System.out.print("Enter Salary of each Employee");
		String salary = sc.nextLine();
		sc.nextLine();
		
		String sql ="UPDATE EmployeesContactInfo SET first_name = ?,last_name = ?,gender = ? , dob = ?,phone = ?,department =?,position =?,hire_date = ?,salary=?";
		try(PreparedStatement stmt = conn.prepareStatement(sql)){
			stmt.setString(1, first_name);
			stmt.setString(2, last_name);
			stmt.setString(3, gender);
			stmt.setString(4, dob);
			stmt.setString(5, phone );
			stmt.setString(6,  department);
			stmt.setString(7,  position);
			stmt.setString(8, hire_date);
			stmt.setString(9,  salary);
			
			int rows = stmt.executeUpdate();
			
			if(rows>0) {
				System.out.println("Employee's Information Updated");
				
			}
			else {
				System.out.println("Employee not found");
			}
				
		}
		
		
	}
	
	public static void deleteEmployee(Connection conn, Scanner sc) throws SQLException{
		System.out.print("Enter Employee's ID to delete:");
		int id = sc.nextInt();
		
		String sql = "DELETE FROM EmployeesContactInfo where id =?";
		try(PreparedStatement stmt = conn.prepareStatement(sql)){
			stmt.setInt(1, id);
			int rows = stmt.executeUpdate();
			if(rows >0) {
				System.out.println("Employee's Contact Deleted");
				
			} else
			{
				System.out.println("Employee not Found.");
			}
		}
		
	}
	
	public static void searchEmployee(Connection conn, Scanner sc) throws SQLException
	{
		System.out.print("Enter name of Employee to search:");
		String name = sc.nextLine();
		
		String sql = "SELECT * FROM EmployeesContactInfo WHERE first_name LIKE ?";
		try(PreparedStatement stmt = conn.prepareStatement(sql)){
			stmt.setString(1,  "%" + name + "%");
			try(ResultSet rs = stmt.executeQuery()) {
				System.out.println("\n ----- Search Results ------");
				boolean found = false;
				while(rs.next()) {
					found = true;
					System.out.printf("%d | %s | %s | %s | %s | %s |%s | %s | %s | %s \n",
							rs.getInt("id"),
							rs.getString("first_name"),
							rs.getString("last_name"),
							rs.getString("gender"),
							rs.getString("dob"),
							rs.getString("phone"),
							rs.getString("department"),
							rs.getString("position"),
							rs.getString("hire_date"),
							rs.getString("salary"));
							
							
							
							
							
							
							
				}
				if(!found) 
				{						
					System.out.println("No matching Employee found.");
				}
			}
		}
		
	}
	
	
}
